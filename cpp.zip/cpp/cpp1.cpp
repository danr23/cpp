#include<iostream>
using namespace std;
int main() {
double x, y;
cout<<"\n\t\t\tEnter first number \n\t\t\t\n\t\t\t";
cin>>x;
cout<<"\n\t\t\tEnter second number \n\t\t\t\n\t\t\t";
cin>>y;
cout<<"\n\t\t\t"<<(x)<<"+"<<(y)<<" = "<<(x+y)<<"\n"<<endl;
cout<<"\t\t\t"<<(x)<<"-"<<(y)<<" = "<<(x-y)<<"\n"<<endl;
cout<<"\t\t\t"<<(x)<<"*"<<(y)<<" = "<<(x*y)<<"\n"<<endl;
cout<<"\t\t\t"<<(x)<<"/"<<(y)<<" = "<<(x/y)<<"\n"<<endl;
cout<<"\t\t\t";
}
