#include<iostream>
using namespace std;


int main()
{
cout << "\n\n" <<endl;
cout << "\t\t\tHello" <<endl;
cout << "\n\n" <<endl;
int x = 1;
int y = 2;
int *p;
p = &x;
cout << "\t\tPassword = " << p << endl;
cout << "\n\n" <<endl;
cout << "\t\t";
}
